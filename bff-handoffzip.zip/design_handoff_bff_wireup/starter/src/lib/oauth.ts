import { BrowserOAuthClient } from '@atproto/oauth-client-browser';

// Scope: `atproto` is required; `transition:generic` grants generic repo
// read/write so we can putRecord / listRecords on app.bff.pick.
export const OAUTH_SCOPE = 'atproto transition:generic';

// In DEV, AT Protocol supports a "loopback" client: the client_id is
// http://localhost with redirect_uri + scope passed as query params — no hosted
// metadata required. In PROD, host /client-metadata.json and set
// VITE_OAUTH_CLIENT_ID to its public URL (see public/client-metadata.json).
const clientId = import.meta.env.DEV
  ? `http://localhost?redirect_uri=${encodeURIComponent(
      window.location.origin + '/',
    )}&scope=${encodeURIComponent(OAUTH_SCOPE)}`
  : (import.meta.env.VITE_OAUTH_CLIENT_ID as string);

let _client: BrowserOAuthClient | null = null;

/** Lazily create the singleton OAuth client (loads/validates client metadata). */
export async function getOAuthClient(): Promise<BrowserOAuthClient> {
  if (_client) return _client;
  _client = await BrowserOAuthClient.load({
    clientId,
    // Public service used only to resolve handles → DIDs → PDS during sign-in.
    handleResolver: 'https://bsky.social',
  });
  return _client;
}
