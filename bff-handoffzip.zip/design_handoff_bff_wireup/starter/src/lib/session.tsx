import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import { Agent } from '@atproto/api';
import type { OAuthSession } from '@atproto/oauth-client-browser';
import { getOAuthClient, OAUTH_SCOPE } from './oauth';

export type Session = {
  agent: Agent;
  did: string;
  handle: string;
} | null;

type SessionCtx = {
  session: Session;
  /** true until the initial init()/callback resolution finishes */
  loading: boolean;
  /** Begins OAuth: resolves the handle's PDS and redirects the browser there. */
  signIn: (handle: string) => Promise<void>;
  signOut: () => Promise<void>;
};

const Ctx = createContext<SessionCtx | undefined>(undefined);

async function toSession(oauthSession: OAuthSession): Promise<Session> {
  const agent = new Agent(oauthSession);
  const did = oauthSession.did;
  let handle = did;
  try {
    const prof = await agent.getProfile({ actor: did });
    handle = prof.data.handle;
  } catch {
    /* fall back to DID if profile fetch fails */
  }
  return { agent, did, handle };
}

export function SessionProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session>(null);
  const [loading, setLoading] = useState(true);

  // Run once on load: init() completes a pending OAuth callback AND restores an
  // existing (persisted, auto-refreshing) session if there is one.
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const client = await getOAuthClient();
        const result = await client.init();
        if (active && result?.session) {
          setSession(await toSession(result.session));
        }
      } catch (err) {
        console.error('OAuth init failed', err);
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const signIn = useCallback(async (handle: string) => {
    const client = await getOAuthClient();
    // Redirects away; only returns (throws) on failure to start.
    await client.signIn(handle.trim().replace(/^@/, ''), { scope: OAUTH_SCOPE });
  }, []);

  const signOut = useCallback(async () => {
    const client = await getOAuthClient();
    if (session) await client.revoke(session.did);
    setSession(null);
  }, [session]);

  return (
    <Ctx.Provider value={{ session, loading, signIn, signOut }}>
      {children}
    </Ctx.Provider>
  );
}

export function useSession(): SessionCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useSession must be used within <SessionProvider>');
  return ctx;
}
