import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSession } from '../lib/session';

/**
 * OAuth callback landing page.
 *
 * SessionProvider.init() runs on app mount and handles the OAuth code/state
 * in the URL automatically (it calls oauthClient.init() which completes the
 * PKCE exchange and persists the session). This component just waits for that
 * to finish, then navigates home. If something went wrong it falls back to /login.
 */
export default function Callback() {
  const { session, loading } = useSession();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      navigate(session ? '/' : '/login', { replace: true });
    }
  }, [session, loading, navigate]);

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 16,
      background: 'var(--page-bg)',
      fontFamily: 'var(--font-ui)',
      color: 'var(--faint)',
    }}>
      {/* Wordmark */}
      <div style={{ display: 'flex', gap: 3 }}>
        {([['#C2902F', '★'], ['#CC6B52', '♥'], ['#2E9E78', '①']] as const).map(
          ([bg, g]) => (
            <span key={g} style={{
              width: 22, height: 22, borderRadius: 6, background: bg,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--on-brand)', fontSize: 11,
            }}>{g}</span>
          ),
        )}
      </div>
      <span style={{ fontSize: 15 }}>Signing you in…</span>
    </div>
  );
}
